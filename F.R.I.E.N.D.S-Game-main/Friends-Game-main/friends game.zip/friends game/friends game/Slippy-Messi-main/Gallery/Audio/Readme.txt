All the important and required sounds
